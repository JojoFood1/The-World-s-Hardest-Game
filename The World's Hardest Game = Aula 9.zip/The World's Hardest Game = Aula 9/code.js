var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var score = 0
var player = createSprite(25,200,15,15)
player.shapeColor = "green"
var wall = createSprite(200,100,400,5)
var wall2 = createSprite(200,300,400,5)
var car1 = createSprite(110,115,15,15)
car1.shapeColor = "red"
var car2 = createSprite(160,280,15,15)
car2.shapeColor = "red"
var car3 = createSprite(210,115,15,15)
car3.shapeColor = "red"
var car4 = createSprite(255,280,15,15)
car4.shapeColor = "red"

car1.velocityY = 9
car2.velocityY = -9
car3.velocityY = 9
car4.velocityY = -9

createEdgeSprites()

playSound("assets/category_background/eerie_beginnings.mp3", true);

function draw() {
  
background("white")
 
 textSize(20)
 
 fill("black")
 
 text("Deaths: "+score, 300,25)
  
fill("#ADD8E6")
rect(-1,100,80,200)  
 
fill("#FFFF00") 
rect(320,100,80,200)
  
if(keyDown("left")) {
  player.x = player.x-3
} 

if(keyDown("right")){
  player.x = player.x+3
}  
  

car1.bounceOff(wall)
car1.bounceOff(wall2)
car2.bounceOff(wall)
car2.bounceOff(wall2)
car3.bounceOff(wall)
car3.bounceOff(wall2)
car4.bounceOff(wall)
car4.bounceOff(wall2)
player.bounceOff(edges)

if(player.isTouching(car1) || player.isTouching(car2) || player.isTouching(car3) || player.isTouching(car4)){
  player.x = 25
  score = score+1
}

 
  
drawSprites()
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
